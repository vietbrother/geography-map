import React, {Component} from 'react';
import {View} from 'react-native';

export default class ChatListHeader extends Component {


  render() {
    return (
      <View />
    )
  }

}